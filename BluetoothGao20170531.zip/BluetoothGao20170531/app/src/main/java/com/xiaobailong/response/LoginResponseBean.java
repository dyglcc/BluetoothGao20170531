package com.xiaobailong.response;

/**
 * Created by dongyuangui on 2017/12/30.
 */

public class LoginResponseBean extends ResponseData {





}
