package com.xiaobailong_student.model;

/**
 * Created by dongyuangui on 2017/6/5.
 */

public class FaultBean {
    private int type = -1;
    private String value;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
