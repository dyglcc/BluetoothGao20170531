package com.xiaobailong_student.result;

/**
 * Created by dongyuangui on 2017/12/30.
 */

public class LoginRes extends ResponseLoginData {



}
