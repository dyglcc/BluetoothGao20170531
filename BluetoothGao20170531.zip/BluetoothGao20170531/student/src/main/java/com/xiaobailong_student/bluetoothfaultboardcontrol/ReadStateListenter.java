package com.xiaobailong_student.bluetoothfaultboardcontrol;

/**
 * Created by dongyuangui on 2017/6/27.
 */

public interface ReadStateListenter {
    void onConnected();
}
